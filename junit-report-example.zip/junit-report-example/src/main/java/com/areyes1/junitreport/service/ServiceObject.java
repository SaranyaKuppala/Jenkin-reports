package com.areyes1.junitreport.service;

public class ServiceObject {

	private String metaData;
	private String name;
	private String description;
	private Integer controlNo;
	private String status;
	
	public String getMetaData() {
		return metaData;
	}
	public void setMetaData(String metaData) {
		this.metaData = metaData;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getControlNo() {
		return controlNo;
	}
	public void setControlNo(Integer controlNo) {
		this.controlNo = controlNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
